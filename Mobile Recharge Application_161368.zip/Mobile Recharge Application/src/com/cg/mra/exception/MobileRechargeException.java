package com.cg.mra.exception;

public class MobileRechargeException extends Exception {
	public MobileRechargeException(String msg){
		super(msg);
	}

}
